# Smart mess management > 2025-09-02 11:19pm
https://universe.roboflow.com/iot-project-kmczx/smart-mess-management-klg4f

Provided by a Roboflow user
License: CC BY 4.0

